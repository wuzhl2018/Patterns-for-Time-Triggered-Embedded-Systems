/*------------------------------------------------------------------*-

   Main.c (v1.00)

  ------------------------------------------------------------------

   Demo program for bargraph display

   
   ---

   This code is copyright (c) 2014-2015 SafeTTy Systems Ltd.

   This code forms part of a Time-Triggered Reference Design
   that is documented in the following book: 

   PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont
   [Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

   This code is intended (only) to demonstrate the use of some simple
   Time-Triggered system architectures.

   THIS CODE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY AS TO ITS
   SUITABILITY FOR ANY PURPOSE.

   THIS CODE IS NOT SUITABLE FOR USE IN ANY FORM OF PRODUCT.

   This code may be used without charge: [i] by universities and
   colleges in courses for which a degree up to and including MSc 
   level (or equivalent) is awarded; [ii] for non-commercial projects
   carried out by individuals and hobbyists.

   Please see the SafeTTy Systems WWW site for alternative code
   libraries and products that are suitable for use in a range of
   production systems:   

   http://www.safetty.net/
   
-*------------------------------------------------------------------*/

#include "Main.h"
#include "Bargraph.h"

// ------ Public variable declarations -----------------------------

extern tBargraph Data_G;

/* ............................................................... */
/* ............................................................... */

void main(void)
   {
   tWord x;

   BARGRAPH_Init();

   while(1)
      {
      if (++x == 1000)
         {
         x = 0;
         Data_G++;
         }

      BARGRAPH_Update();
      }
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/

