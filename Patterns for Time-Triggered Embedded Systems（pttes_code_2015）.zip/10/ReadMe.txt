
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 10.

The sub-directories are as follows:

10\Bytes
Contains the files associated with Listing 10-1.

10\Bits1
Contains the files associated with Listing 10-2.

10\Bits2
Contains the files associated with Listing 10-3.

10\Bits1
Contains the files associated with Listing 10-5 to Listing 10-8.


