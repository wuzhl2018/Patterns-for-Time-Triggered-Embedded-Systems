
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 12.

The sub-directories are as follows:

12\WDog1232
Contains the project associated with Listing 12-1 to Listing 12-2.

12\WDog8953
Contains the project associated with Listing 12-3 to Listing 12-7.

