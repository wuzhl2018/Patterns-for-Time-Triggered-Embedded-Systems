/*------------------------------------------------------------------*-

   Printf51.C (v1.00)

  ------------------------------------------------------------------
   
   A simple serial initialisation routine to allow Keil hardware
   simulator to be used to run 'desktop' C examples.

   [Full details of a complete serial interface library are given
   in Chapter 18.  This code is for demo purposes only!!! ]

   
   ---

   This code is copyright (c) 2014-2015 SafeTTy Systems Ltd.

   This code forms part of a Time-Triggered Reference Design
   that is documented in the following book: 

   PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont
   [Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

   This code is intended (only) to demonstrate the use of some simple
   Time-Triggered system architectures.

   THIS CODE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY AS TO ITS
   SUITABILITY FOR ANY PURPOSE.

   THIS CODE IS NOT SUITABLE FOR USE IN ANY FORM OF PRODUCT.

   This code may be used without charge: [i] by universities and
   colleges in courses for which a degree up to and including MSc 
   level (or equivalent) is awarded; [ii] for non-commercial projects
   carried out by individuals and hobbyists.

   Please see the SafeTTy Systems WWW site for alternative code
   libraries and products that are suitable for use in a range of
   production systems:   

   http://www.safetty.net/
   
-*------------------------------------------------------------------*/

#include "Main.h"
#include "Printf51.h"

/*------------------------------------------------------------------*-

  Printf51_Init()

  A simple serial initialisation routine to allow Keil hardware
  simulator to be used to run 'desktop' C examples.

-*------------------------------------------------------------------*/
void Printf51_Init(void)
   {
   const tWord BAUD_RATE = 9600;

   PCON &= 0x7F;   // Set SMOD bit to 0 (don't double baud rates)

   //  Receiver enabled.
   //  8-bit data, 1 start bit, 1 stop bit, 
   //  Variable baud rate (asynchronous)
   //  Receive flag will only be set if a valid stop bit is received
   //  Set TI (transmit buffer is empty)
   SCON = 0x72;

   TMOD |= 0x20;   // T1 in mode 2, 8-bit auto reload

   // See Main.H for details of OSC_FREQ and OSC_PER_INST
   TH1 = (256 - (tByte)((((tLong)OSC_FREQ / 100) * 3125) 
            / ((tLong) BAUD_RATE * OSC_PER_INST * 1000)));

   TL1 = TH1;  
   TR1 = 1;  // Run the timer

   TI = 1;   // Send dummy byte

   // Interrupt *NOT* enabled
   ES = 0;
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
