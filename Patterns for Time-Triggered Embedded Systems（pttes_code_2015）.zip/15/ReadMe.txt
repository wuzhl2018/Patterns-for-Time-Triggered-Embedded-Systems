
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 15.

The sub-directories are as follows:

15\Loop_tst
Contains the project associated with Listing 15-1 and Listing 15-2.

15\Hard_tst
Contains the project associated with Listing 15-3 and Listing 15-4.

