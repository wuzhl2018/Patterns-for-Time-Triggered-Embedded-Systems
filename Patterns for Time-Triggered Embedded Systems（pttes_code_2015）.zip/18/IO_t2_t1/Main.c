/*------------------------------------------------------------------*-

   Main.c (v1.01)

  ------------------------------------------------------------------

   Test program for menu-driven PC link library, generic version.

   Required linker options (see Chapter 14 for details):

   OVERLAY (main ~ (MENU_Command_Processor), 
   SCH_Dispatch_Tasks ! (MENU_Command_Processor))

   
   ---

   This code is copyright (c) 2014-2015 SafeTTy Systems Ltd.

   This code forms part of a Time-Triggered Reference Design
   that is documented in the following book: 

   PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont
   [Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

   This code is intended (only) to demonstrate the use of some simple
   Time-Triggered system architectures.

   THIS CODE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY AS TO ITS
   SUITABILITY FOR ANY PURPOSE.

   THIS CODE IS NOT SUITABLE FOR USE IN ANY FORM OF PRODUCT.

   This code may be used without charge: [i] by universities and
   colleges in courses for which a degree up to and including MSc 
   level (or equivalent) is awarded; [ii] for non-commercial projects
   carried out by individuals and hobbyists.

   Please see the SafeTTy Systems WWW site for alternative code
   libraries and products that are suitable for use in a range of
   production systems:   

   http://www.safetty.net/
   
-*------------------------------------------------------------------*/

#include "Main.h"
#include "2_05_11g.h"
#include "PC_IO_T1.h"
#include "Menu_A.h"

/* ............................................................... */
/* ............................................................... */

void main(void)
   {
   // Set up the scheduler
   SCH_Init_T2();

   // Set baud rate to 9600: generic 8051 version
   PC_LINK_IO_Init_T1(9600);

   // We have to schedule this task (10x - 100x a second)
   //
   // TIMING IS IN TICKS NOT MILLISECONDS (5 ms tick interval)
   SCH_Add_Task(MENU_Command_Processor,10,2);

   SCH_Start();

   while(1)
      {
      // Displays error codes on P4 (see Sch51.C)
      SCH_Dispatch_Tasks();
      }
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
