
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 19.

The sub-directories are as follows:

19\Switch_A
Contains the project associated with Listing 19-1 to Listing 19-4.

19\On_Off
Contains the project associated with Listing 19-6 to Listing 19-9.

19\Multi_S
Contains the project associated with Listing 19-10 to Listing 19-14.
