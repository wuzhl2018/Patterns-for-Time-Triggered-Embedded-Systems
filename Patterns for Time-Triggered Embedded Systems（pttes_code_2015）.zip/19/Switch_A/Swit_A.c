/*------------------------------------------------------------------*-

   SWIT_A.C (v1.00)
 
  ------------------------------------------------------------------

   Simple switch interface code, with software debounce.

   
   ---

   This code is copyright (c) 2014-2015 SafeTTy Systems Ltd.

   This code forms part of a Time-Triggered Reference Design
   that is documented in the following book: 

   PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont
   [Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

   This code is intended (only) to demonstrate the use of some simple
   Time-Triggered system architectures.

   THIS CODE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY AS TO ITS
   SUITABILITY FOR ANY PURPOSE.

   THIS CODE IS NOT SUITABLE FOR USE IN ANY FORM OF PRODUCT.

   This code may be used without charge: [i] by universities and
   colleges in courses for which a degree up to and including MSc 
   level (or equivalent) is awarded; [ii] for non-commercial projects
   carried out by individuals and hobbyists.

   Please see the SafeTTy Systems WWW site for alternative code
   libraries and products that are suitable for use in a range of
   production systems:   

   http://www.safetty.net/
   
-*------------------------------------------------------------------*/

#include "Main.h"
#include "Port.h"

#include "Swit_A.h"

// ------ Public variable definitions ------------------------------

bit Sw_pressed_G = 0; // The current switch status


// ------ Private constants ----------------------------------------

// Allows NO or NC switch to be used (or other wiring variations)
#define SW_PRESSED (0)

// SW_THRES must be > 1 for correct debounce behaviour
#define SW_THRES (3)


/*------------------------------------------------------------------*-

  SWITCH_Init()

  Initialisation function for the switch library.

-*------------------------------------------------------------------*/
void SWITCH_Init(void)
   {
   Sw_pin = 1; // Use this pin for input
   }

/*------------------------------------------------------------------*-

  SWITCH_Update()
  
  This is the main switch function.  

  It should be scheduled every 50 - 500 ms.
 
-*------------------------------------------------------------------*/
void SWITCH_Update(void)
   {
   static tByte Duration;

   if (Sw_pin == SW_PRESSED)
      {
      Duration += 1;

      if (Duration > SW_THRES)
         {
         Duration = SW_THRES;

         Sw_pressed_G = 1;  // Switch is pressed...
         return;
         }

      // Switch pressed, but not yet for long enough
      Sw_pressed_G = 0;
      return; 
      }
    
   // Switch not pressed - reset the count
   Duration = 0;
   Sw_pressed_G = 0;  // Switch not pressed...
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
