
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 21.

The sub-directory is as follows:

21\LED_Time
Contains the project associated with Listing 21-2 to Listing 21-5.

