/*------------------------------------------------------------------*-

   Main.c (v1.00)

  ------------------------------------------------------------------
   
   TEST PROGRAM FOR LCD LIBRARY CODE

   * Designed for 2-line x 20-character HD44780-based display 
   * '4-BIT' INTERFACE (uses 6 pins...) 
   * Requires T0 (for delays and timeouts) 

   Required linker options (see Chapter 14 for details):

   OVERLAY (main ~ (Elapsed_Time_LCD_Update,LCD_Update), 
   Sch_Dispatch_Tasks ! (Elapsed_Time_LCD_Update,LCD_Update))

   
   ---

   This code is copyright (c) 2014-2015 SafeTTy Systems Ltd.

   This code forms part of a Time-Triggered Reference Design
   that is documented in the following book: 

   PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont
   [Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

   This code is intended (only) to demonstrate the use of some simple
   Time-Triggered system architectures.

   THIS CODE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY AS TO ITS
   SUITABILITY FOR ANY PURPOSE.

   THIS CODE IS NOT SUITABLE FOR USE IN ANY FORM OF PRODUCT.

   This code may be used without charge: [i] by universities and
   colleges in courses for which a degree up to and including MSc 
   level (or equivalent) is awarded; [ii] for non-commercial projects
   carried out by individuals and hobbyists.

   Please see the SafeTTy Systems WWW site for alternative code
   libraries and products that are suitable for use in a range of
   production systems:   

   http://www.safetty.net/
   
-*------------------------------------------------------------------*/

#include "Main.h"
#include "LCD_A.h"
#include "2_01_12g.h"
#include "Elap_LCD.h"

/* ............................................................... */
void main(void)
   {
   // Initialisation can be problematic with some display / supply
   // combinations.  You may get away with calling this function
   // twice (or once) but - for maximum reliability under a very wide range 
   // of conditions - it is called three times here.
   LCD_Init(0);
   LCD_Init(0);
   LCD_Init(1);

   // Prepare the elapsed time library
   Elapsed_Time_LCD_Init();

   // Prepare the scheduler
   SCH_Init_T2();

   // Add tasks to the scheduler
   //
   // Update the time every second (*** 1ms sched ticks ***)
   SCH_Add_Task(Elapsed_Time_LCD_Update, 100, 1000);

   // Update the whole display ~ every second 
   // - do this by updating a character once every 24 ms
   // (assumes a 40 character display)
   SCH_Add_Task(LCD_Update, 1000, 24);

   // All tasks added: start running the scheduler
   SCH_Start();   

   while(1)
      {
      SCH_Dispatch_Tasks();
      }
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/

