
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 22.

The sub-directories are as follows:

22\LCD_Time
Contains the project associated with Listing 22-1 to Listing 22-3.

22\LCD_Key
Contains the project associated with Listing 22-4 to Listing 22-6.

