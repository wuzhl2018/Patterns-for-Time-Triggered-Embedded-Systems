
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 24.

The sub-directories are as follows:

24\SPI_ROM
Contains the project associated with Listing 24-1 to Listing 24-6.



