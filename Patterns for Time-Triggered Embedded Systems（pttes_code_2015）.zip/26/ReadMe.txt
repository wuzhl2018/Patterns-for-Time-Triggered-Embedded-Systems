
PATTERNS FOR TIME-TRIGGERED EMBEDDED SYSTEMS by Michael J. Pont 
[Originally published Addison-Wesley, 2001; ISBN: 0-201-33138-1]

----------

This directory contains the files from Chapter 26.

The sub-directories are as follows:

26\SCI_Ti1\SCI_Ti1m
Contains the project associated with Listing 26-1 to Listing 26-4.

26\SCI_Ti1\SCI_Ti1s
Contains the project associated with Listing 26-5 to Listing 26-7.

--

26\SCI_Ti2\SCI_Ti2m
Contains the project associated with Listing 26-8.

26\SCI_Ti2\SCI_Ti2s
Contains the project associated with Listing 26-9.

--

26\SCI_Data\SCI_Dm
Contains the project associated with Listing 26-10.

26\SCI_Data\SCI_Ds
Contains the project associated with Listing 26-11.

